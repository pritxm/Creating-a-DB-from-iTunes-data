# XML-Data--to-SQL
Using XML Data obtained from the iTunes API and extracting useful information about tracks from the same. Storing this information by writing a Python Script into a NoSQL Database which can be easily retrieved using SQL Commands.
